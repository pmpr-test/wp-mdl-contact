<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8913b043             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Contact\Traits\SettingTrait; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { use SettingTrait; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\145\146\x6f\162\145\137\x72\145\156\x64\x65\x72\x5f\142\x72\x61\x6e\x64\x5f\163\143\150\145\x6d\x61", [$this, "\x6e\147\141\x61\147\141\143\151\171\147\157\x6b\163\x6b\145\x67"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); if (!$ciyacayigmkuskgg instanceof Brand) { goto asmecuqiyyswueqe; } $naiuumgusmkcowsa = $this->awiwgkaewoyqysas([Constants::aisguagukaewucii => Constants::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($gkyciwoiiisgywcs->get($kyocyoemugcyqqyu, Constants::auqoykcmsiauccao)); myoicgcuugciueis: } qwigomakwmyiwkgo: asmecuqiyyswueqe: return $ciyacayigmkuskgg; } }
