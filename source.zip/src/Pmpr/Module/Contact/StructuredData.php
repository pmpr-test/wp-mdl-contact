<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d97f8512be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\x65\146\157\162\145\x5f\162\145\156\144\145\162\137\x62\x72\x61\x6e\x64\x5f\163\143\x68\x65\x6d\141", [$this, "\x6e\x67\x61\x61\147\141\143\x69\171\x67\x6f\x6b\x73\153\145\x67"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { if ($ciyacayigmkuskgg instanceof Brand) { $naiuumgusmkcowsa = $this->kmuweyayaqoeqiyw()->yeokamaagskewssa([Constants::aisguagukaewucii => Constants::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($kyocyoemugcyqqyu[Constants::auqoykcmsiauccao] ?? ''); } } return $ciyacayigmkuskgg; } }
