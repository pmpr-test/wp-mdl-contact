<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78c8fb79             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Contact\Traits\SettingTrait; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { use SettingTrait; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\142\145\146\x6f\162\145\x5f\x72\145\x6e\144\x65\x72\x5f\142\x72\141\x6e\x64\137\163\x63\x68\145\x6d\141", [$this, "\156\147\x61\x61\x67\x61\x63\151\171\x67\x6f\x6b\x73\x6b\145\x67"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); if (!$ciyacayigmkuskgg instanceof Brand) { goto asmecuqiyyswueqe; } $naiuumgusmkcowsa = $this->awiwgkaewoyqysas([Constants::aisguagukaewucii => Constants::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($gkyciwoiiisgywcs->get($kyocyoemugcyqqyu, Constants::auqoykcmsiauccao)); myoicgcuugciueis: } qwigomakwmyiwkgo: asmecuqiyyswueqe: return $ciyacayigmkuskgg; } }
