<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705310d27397             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Contact\Traits\SettingTrait; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { use SettingTrait; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\142\x65\x66\x6f\162\x65\x5f\162\x65\x6e\144\x65\x72\137\x62\x72\x61\156\x64\137\163\x63\x68\x65\155\141", [$this, "\x6e\147\141\141\x67\x61\x63\x69\x79\x67\157\x6b\163\x6b\x65\x67"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); if ($ciyacayigmkuskgg instanceof Brand) { $naiuumgusmkcowsa = $this->awiwgkaewoyqysas([Constants::aisguagukaewucii => Constants::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($gkyciwoiiisgywcs->get($kyocyoemugcyqqyu, Constants::auqoykcmsiauccao)); } } return $ciyacayigmkuskgg; } }
