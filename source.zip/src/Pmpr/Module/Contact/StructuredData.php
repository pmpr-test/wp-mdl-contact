<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051761b584d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Contact\Traits\SettingTrait; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { use SettingTrait; public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\x65\146\157\x72\145\137\162\145\x6e\x64\145\162\x5f\x62\162\141\156\144\x5f\x73\143\150\145\x6d\x61", [$this, "\156\x67\x61\x61\147\x61\x63\151\171\x67\x6f\x6b\163\x6b\145\147"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); if (!$ciyacayigmkuskgg instanceof Brand) { goto sciwggaeogcoesiu; } $naiuumgusmkcowsa = $this->awiwgkaewoyqysas([Constants::aisguagukaewucii => Constants::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($gkyciwoiiisgywcs->get($kyocyoemugcyqqyu, Constants::auqoykcmsiauccao)); mkwskuycuyguqqok: } kuicqywysciceggs: sciwggaeogcoesiu: return $ciyacayigmkuskgg; } }
