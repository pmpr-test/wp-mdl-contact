<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6fe58f3a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\142\x65\x66\x6f\x72\145\137\x72\145\x6e\x64\145\x72\x5f\x62\x72\x61\x6e\144\x5f\x73\x63\150\x65\155\x61", [$this, "\x6e\147\141\x61\x67\141\143\151\x79\147\x6f\x6b\x73\153\x65\147"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { if ($ciyacayigmkuskgg instanceof Brand) { $naiuumgusmkcowsa = $this->kmuweyayaqoeqiyw()->yeokamaagskewssa([Constants::aisguagukaewucii => Constants::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($kyocyoemugcyqqyu[Constants::auqoykcmsiauccao] ?? ''); } } return $ciyacayigmkuskgg; } }
