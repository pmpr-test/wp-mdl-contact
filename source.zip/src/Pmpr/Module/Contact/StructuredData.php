<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc07456d95             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\142\145\x66\157\162\145\x5f\x72\x65\156\144\145\x72\137\x62\x72\141\156\144\x5f\x73\x63\x68\145\x6d\141", [$this, "\x6e\x67\x61\141\x67\141\x63\x69\171\147\157\x6b\163\153\x65\147"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { if ($ciyacayigmkuskgg instanceof Brand) { $naiuumgusmkcowsa = $this->kmuweyayaqoeqiyw()->yeokamaagskewssa([Constants::aisguagukaewucii => Constants::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($kyocyoemugcyqqyu[Constants::auqoykcmsiauccao] ?? ''); } } return $ciyacayigmkuskgg; } }
