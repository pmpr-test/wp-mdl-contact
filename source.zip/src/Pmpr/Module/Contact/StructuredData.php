<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670db9401861a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\Intangible\Brand; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\145\146\157\162\145\x5f\162\145\156\144\145\162\x5f\x62\162\141\x6e\144\137\x73\143\150\145\x6d\141", [$this, "\156\147\x61\x61\x67\141\x63\151\171\x67\157\153\x73\153\145\147"]); } public function ngaagaciygokskeg($ciyacayigmkuskgg) { if ($ciyacayigmkuskgg instanceof Brand) { $naiuumgusmkcowsa = $this->kmuweyayaqoeqiyw()->yeokamaagskewssa([Constants::aisguagukaewucii => Constants::ckmqoekmugkggeym]); foreach ($naiuumgusmkcowsa as $kyocyoemugcyqqyu) { $ciyacayigmkuskgg->sceiycyikekgiqgg($kyocyoemugcyqqyu[Constants::auqoykcmsiauccao] ?? ''); } } return $ciyacayigmkuskgg; } }
