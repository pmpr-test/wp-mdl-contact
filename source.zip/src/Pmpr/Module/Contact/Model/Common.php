<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051761b584d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Common\Foundation\ORM\Model; abstract class Common extends Model { }
