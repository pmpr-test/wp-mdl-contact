<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78c8fb79             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends Common { const yoigiwuoqmuawggk = "\163\x75\142\x6d\x69\x73\x73\x69\x6f\x6e\x5f\151\x64"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::ckqqkkgqwgmckeao)->guiaswksukmgageq(__("\122\x65\x73\x70\x6f\156\x73\145", PR__MDL__CONTACT))->muuwuqssqkaieqge(__("\x52\x65\163\160\x6f\156\x73\145\163", PR__MDL__CONTACT))->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->usqseiuaeauwuwus(Constants::meksegaoamowuwoq)->gswweykyogmsyawy(__("\125\x73\145\x72", PR__MDL__CONTACT)), $this->gysoeyaguiyewoes(Constants::eoskkkieowogacws)->gswweykyogmsyawy(__("\115\145\163\x73\141\147\145", PR__MDL__CONTACT)), $this->eoaomaokwkwqyqiq(self::yoigiwuoqmuawggk)->gswweykyogmsyawy(__("\x53\165\x62\x6d\x69\x73\x73\151\157\156", PR__MDL__CONTACT))]); parent::ewaqwooqoqmcoomi(); } }
