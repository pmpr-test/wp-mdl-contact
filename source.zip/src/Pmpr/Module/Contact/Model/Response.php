<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800fba93eaf0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Common\Foundation\ORM\Model; class Response extends Model { const yoigiwuoqmuawggk = 'submission_id'; public function register() { $this->saemoowcasogykak(IconInterface::ckqqkkgqwgmckeao)->guiaswksukmgageq(__('Response', PR__MDL__CONTACT))->muuwuqssqkaieqge(__('Responses', PR__MDL__CONTACT)); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->usqseiuaeauwuwus(Constants::meksegaoamowuwoq)->gswweykyogmsyawy(__('User', PR__MDL__CONTACT)))->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::eoskkkieowogacws)->gswweykyogmsyawy(__('Message', PR__MDL__CONTACT)))->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(self::yoigiwuoqmuawggk)->gswweykyogmsyawy(__('Submission', PR__MDL__CONTACT)))->cquokmemekqqywgi($eqwoegegiamegqsm->qwwuoqeeiyuoyogs(Constants::CREATED_AT)->gswweykyogmsyawy(__('Created At', PR__MDL__CONTACT))); parent::uwmqacgewuauagai(); } }
