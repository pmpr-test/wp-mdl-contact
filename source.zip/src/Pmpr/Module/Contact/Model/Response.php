<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec18285f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends Common { const yoigiwuoqmuawggk = "\x73\x75\142\x6d\151\x73\x73\x69\157\156\x5f\151\x64"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::ckqqkkgqwgmckeao)->guiaswksukmgageq(__("\122\x65\x73\x70\x6f\156\x73\145", PR__MDL__CONTACT))->muuwuqssqkaieqge(__("\x52\x65\x73\160\x6f\156\163\x65\163", PR__MDL__CONTACT))->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->usqseiuaeauwuwus(Constants::meksegaoamowuwoq)->gswweykyogmsyawy(__("\125\x73\145\162", PR__MDL__CONTACT)), $this->gysoeyaguiyewoes(Constants::eoskkkieowogacws)->gswweykyogmsyawy(__("\x4d\145\x73\x73\x61\147\x65", PR__MDL__CONTACT)), $this->eoaomaokwkwqyqiq(self::yoigiwuoqmuawggk)->gswweykyogmsyawy(__("\x53\x75\142\155\x69\x73\x73\151\157\156", PR__MDL__CONTACT))]); parent::ewaqwooqoqmcoomi(); } }
