<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051761b584d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends Common { const yoigiwuoqmuawggk = "\163\x75\142\155\x69\x73\163\x69\157\156\x5f\151\144"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::ckqqkkgqwgmckeao)->guiaswksukmgageq(__("\x52\x65\x73\x70\x6f\x6e\163\145", PR__MDL__CONTACT))->muuwuqssqkaieqge(__("\122\145\163\x70\157\x6e\x73\x65\x73", PR__MDL__CONTACT))->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->usqseiuaeauwuwus(Constants::meksegaoamowuwoq)->gswweykyogmsyawy(__("\125\163\145\x72", PR__MDL__CONTACT)), $this->gysoeyaguiyewoes(Constants::eoskkkieowogacws)->gswweykyogmsyawy(__("\115\145\163\163\x61\x67\x65", PR__MDL__CONTACT)), $this->eoaomaokwkwqyqiq(self::yoigiwuoqmuawggk)->gswweykyogmsyawy(__("\123\x75\x62\155\151\x73\x73\x69\x6f\x6e", PR__MDL__CONTACT))]); parent::ewaqwooqoqmcoomi(); } }
