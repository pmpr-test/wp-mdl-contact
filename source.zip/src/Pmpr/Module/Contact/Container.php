<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc71d52d3f9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const wqimawoummkeeugk = 'contact_'; }
