<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e585efd421f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Contact; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const wqimawoummkeeugk = 'contact_'; }
